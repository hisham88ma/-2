const express = require("express");
const app = express();
const cors = require("cors");

app.use(cors());
app.use(express.json());

let persons = [
  { id: 1, name: "أحمد محمد", number: "0912345678" },
  { id: 2, name: "سارة علي", number: "0923456789" },
  { id: 3, name: "ليلى حسن", number: "0934567890" },
];

const generateId = () => Math.floor(Math.random() * 100000) + 1;

app.get("/api/persons", (req, res) => {
  res.json(persons);
});

app.post("/api/persons", (req, res) => {
  const body = req.body;

  if (!body.name || !body.number) {
    return res.status(400).json({ error: "الاسم والرقم مطلوبان" });
  }

  const exists = persons.some(
    (p) => p.name.trim().toLowerCase() === body.name.trim().toLowerCase()
  );

  if (exists) {
    return res.status(400).json({ error: "الاسم موجود مسبقاً" });
  }

  const newPerson = {
    id: generateId(),
    name: body.name.trim(),
    number: body.number.trim(),
  };

  persons.push(newPerson);
  res.status(201).json(newPerson);
});

app.put("/api/persons/:id", (req, res) => {
  const id = Number(req.params.id);
  const body = req.body;

  if (!body.number) {
    return res.status(400).json({ error: "الرقم مطلوب" });
  }

  const personExists = persons.some((p) => p.id === id);

  if (!personExists) {
    return res.status(404).json({ error: "الشخص غير موجود" });
  }

  persons = persons.map((p) =>
    p.id === id ? { ...p, number: body.number.trim() } : p
  );

  res.json({ id, ...body });
});

app.delete("/api/persons/:id", (req, res) => {
  const id = Number(req.params.id);
  persons = persons.filter((p) => p.id !== id);
  res.status(204).end();
});

const PORT = 3001;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});